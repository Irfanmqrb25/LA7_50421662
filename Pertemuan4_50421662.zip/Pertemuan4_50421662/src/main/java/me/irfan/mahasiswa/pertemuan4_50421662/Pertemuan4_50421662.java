/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package me.irfan.mahasiswa.pertemuan4_50421662;

/**
 *
 * @author ACER
 */
public class Pertemuan4_50421662 {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
