/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package me.irfan.mahasiswa.controller;

import me.irfan.mahasiswa.model.MahasiswaDao;
import me.irfan.mahasiswa.model.ModelMahasiswa;
import java.util.List;

/**
 *
 * @author ACER
 */

public class MahasiswaController {
    private MahasiswaDao mahasiswaDao;
    
    public MahasiswaController(MahasiswaDao mahasiswaDao) {
        this.mahasiswaDao = mahasiswaDao;
    }
    
    public void displayMahasiswaList(List<ModelMahasiswa> mahasiswaList) {
        if(mahasiswaList.isEmpty()) {
            System.out.println("Tidak ada data mahasiswa");
        } else {
            System.out.println("");
            System.out.println("===============================");
            for(ModelMahasiswa m: mahasiswaList) {
                System.out.println("ID        : " + m.getId());
                System.out.println("NPM       : " + m.getNpm());
                System.out.println("NAMA      : " + m.getNama());
                System.out.println("SEMESTER  : " + m.getSemester());
                System.out.println("IPK       : " + m.getIpk());
                System.out.println("===============================");
            }
        }
    }
    
    public void displayMessage(String Message) {
        System.out.println(Message);
    }
    
    public void checkDatabaseConnection() {
        boolean isConnected = mahasiswaDao.checkConnection();
        if(isConnected) {
            displayMessage("Koneksi telah berhasil terkoneksi");
        } else {
            displayMessage("Koneksi database gagal terkoneksi");
        }
    }
    
    public void dispayAllMahasiswa() {
        List<ModelMahasiswa> mahasiswaList = mahasiswaDao.getAllMahasiswa();
        displayMahasiswaList(mahasiswaList);
    }
    
    public void addMahasiswa(String npm, String nama, int semester, float ipk) {
        ModelMahasiswa mahasiswaBaru = new ModelMahasiswa(0, npm, nama, semester, ipk);
        System.out.println("Controller Data : " + npm + nama + semester + ipk);
        System.out.println(mahasiswaBaru);
        mahasiswaDao.addMahasiswa(mahasiswaBaru);
        displayMessage("Mahasiswa Berhasil Ditambahkan");
    }
    public void updateMahasiswa(int id, String npm, String nama, int semester, float ipk) {
        ModelMahasiswa mahasiswaBaru = new ModelMahasiswa(id, npm, nama, semester, ipk);
        mahasiswaDao.updateMahasiswa(mahasiswaBaru);
        displayMessage("Mahasiswa Berhasil Ditambahkan");
    }
    public void deleteMahasiswa(int id) {
        mahasiswaDao.deleteMahasiswa(id);
        displayMessage("Mahasiswa berhasil dihapus");
    }
    public void closeConnection(){
        mahasiswaDao.closeConnection();
    }
}