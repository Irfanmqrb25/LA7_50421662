/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package me.irfan.mahasiswa.pert3_50421662;

/**
 *
 * @author ACER
 */
public class Pert3_50421662 {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
