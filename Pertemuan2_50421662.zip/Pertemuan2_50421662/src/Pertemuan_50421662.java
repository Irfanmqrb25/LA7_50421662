public class Pertemuan_50421662 {
    public static void main(String[] args) {
        Mahasiswa mahasiswa = new Mahasiswa("Irfan", "50421662", 21);
        mahasiswa.tampilkanData();
        System.out.println();

        MahasiswaSarjana mahasiswaSarjana = new MahasiswaSarjana("Brian", "11188877", 22, "Informatika");
        mahasiswaSarjana.tampilkanData();
        System.out.println();
    }
}